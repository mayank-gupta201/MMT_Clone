
import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-mmt-blue text-white pt-10 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">MakeMyTrip</h3>
            <p className="text-gray-300 text-sm">
              MakeMyTrip Ltd is an Indian online travel company founded in 2000. 
              Book flights, hotels, trains, buses, and holiday packages.
            </p>
          </div>

          {/* About */}
          <div>
            <h3 className="font-semibold mb-4">About</h3>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li><Link to="/" className="hover:text-white">About Us</Link></li>
              <li><Link to="/" className="hover:text-white">Investor Relations</Link></li>
              <li><Link to="/" className="hover:text-white">Careers</Link></li>
              <li><Link to="/" className="hover:text-white">Corporate Travel</Link></li>
              <li><Link to="/" className="hover:text-white">MMT Foundation</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold mb-4">Support</h3>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li><Link to="/" className="hover:text-white">Customer Support</Link></li>
              <li><Link to="/" className="hover:text-white">Partner Help</Link></li>
              <li><Link to="/" className="hover:text-white">Privacy Policy</Link></li>
              <li><Link to="/" className="hover:text-white">Terms of Service</Link></li>
              <li><Link to="/" className="hover:text-white">Trust & Safety</Link></li>
            </ul>
          </div>

          {/* More */}
          <div>
            <h3 className="font-semibold mb-4">More</h3>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li><Link to="/" className="hover:text-white">Domestic Flights</Link></li>
              <li><Link to="/" className="hover:text-white">International Flights</Link></li>
              <li><Link to="/" className="hover:text-white">Luxury Hotels</Link></li>
              <li><Link to="/" className="hover:text-white">Bus Ticket</Link></li>
              <li><Link to="/" className="hover:text-white">Cab Booking</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 flex flex-col md:flex-row justify-between">
          <p className="text-gray-400 text-sm">© 2025 MakeMyTrip Clone. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <Link to="/" className="text-gray-400 hover:text-white">
              Facebook
            </Link>
            <Link to="/" className="text-gray-400 hover:text-white">
              Twitter
            </Link>
            <Link to="/" className="text-gray-400 hover:text-white">
              Instagram
            </Link>
            <Link to="/" className="text-gray-400 hover:text-white">
              LinkedIn
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
