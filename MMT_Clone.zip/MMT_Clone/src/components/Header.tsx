
import React from 'react';
import { Link } from 'react-router-dom';
import { User } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Header = () => {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className="text-2xl font-bold text-mmt-blue">MakeMyTrip</span>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-mmt-darkGray hover:text-mmt-blue font-medium">
              Flights
            </Link>
            <Link to="/" className="text-mmt-darkGray hover:text-mmt-blue font-medium">
              Hotels
            </Link>
            <Link to="/" className="text-mmt-darkGray hover:text-mmt-blue font-medium">
              Trains
            </Link>
            <Link to="/" className="text-mmt-darkGray hover:text-mmt-blue font-medium">
              Buses
            </Link>
            <Link to="/" className="text-mmt-darkGray hover:text-mmt-blue font-medium">
              Holidays
            </Link>
            <Link to="/" className="text-mmt-darkGray hover:text-mmt-blue font-medium">
              Cabs
            </Link>
          </nav>

          {/* User actions */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" className="flex items-center">
              <User className="h-5 w-5 mr-2" />
              <span className="hidden md:inline">Login or Create Account</span>
              <span className="md:hidden">Login</span>
            </Button>

            <Button size="sm" className="hidden md:flex bg-mmt-orange hover:bg-orange-600 text-white">
              My Trips
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
